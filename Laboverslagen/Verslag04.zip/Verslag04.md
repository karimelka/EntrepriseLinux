Stubbe Gianni   
El Kaddouri Karim

#Entreprise Linux - Opdracht 4 - BIND DNS Services

[TOC]

##Bronnen en bitbucket
###Bronnen
* Bron 1) [CentOS 7 DNS met Bind](http://www.unixmen.com/setting-dns-server-centos-7/)
* Bron 2) [Ansible Modules](http://docs.ansible.com/list_of_files_modules.html)
* Bron 3) [Documentatie Chamilo](https://chamilo.hogent.be/index.php?go=course_viewer&application=application%5Cweblcms&course=15908&tool=assignment&browser=table&tool_action=student_submissions_browser&publication=758030)

###Repositories
* Repo 1) [Bitbucket Repo](https://bitbucket.org/stoel/labo/src/)

## Bind installeren
* Maak een rol aan voor bind (mapstructuur aanmaken).
* In de main.yml bind en bind-utils service installeren en laten runnen.
* Firewall rule toepassen in role (named toevoegen)
* test schrijven voor testen of dns runt.

##Variabelen definiëren
* host_vars editen
* vagrant_host editen
* inventory_dev aanpassen
* site.yml aanpassen: de gepaste roles disablen en enablen

##named.conf
* conf file kopieren van systeem naar template
* waarden aanpassen
* toevoegen in role voor copy
* notify bind service herstarten
* template met variabelen
* zones toevoegen

##Zonebestand forward lookup
* linuxlab.net zonebestand aanmaken onder templates
* deze via vagrant kopieren met ownership en uitvoermode (/var/named)


##Zonebestand reverse lookup
* 2.0.192.in-addr.arpa en 16.172.in-addr.arpa aanmaken
* die ook kopieren (naar /var/named)

##Test
![Test Uitvoer](TestCompletion.png)