Stubbe Gianni   
El Kaddouri Karim

#Entreprise Linux - Opdracht 6 - DHCP

[TOC]

##Bronnen en bitbucket
###Bronnen
* Bron 1) [RedHat Networking Guide](https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/7/html/Networking_Guide/sec-dhcp-configuring-server.html)

###Repositories
* Repo 1) [Bitbucket Repo](https://bitbucket.org/stoel/labo/src/)

##dhcpd.conf
* hier wordt een for-lus gebruikt om subnets te definiëren. (in deze opdracht is het niet noodzakelijk maar de voorziening is er wel al voor de toekomst)
* Voor de machines werd dezelfde aanpak gehanteerd, hier werd het mac adres, hostname en ip adres meegegeven. 

###Variabelen definiëren
* Hier hebben we onze subnet(s) gedefiniëerd en onze machines met vaste ip addressen.

## Vagrantfile
* we hebben de overstap gedaan naar vaste mac-addressen in onze vagrant_hosts om onze dhcp altijd correct te doen werken.
* In onze vagrantfile was een kleine wijziging noodzakelijk de toevoeging van `mac: host['mac']` was genoeg. Ook worden de subnetmasks nu niet meer standaard op `255.255.255.0` ingesteld.


##Test
###Windows Server 2008 R2
In onderstaande test hebben we dhcp in virtualbox uitgeschakeld en op onze windows server automatische ip configuratie ingeschakeld. De volgende correcte uitvoer verkregen wij:
![Test Uitvoer](test.png)