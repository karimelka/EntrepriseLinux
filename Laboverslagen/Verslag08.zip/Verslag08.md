Stubbe Gianni   
El Kaddouri Karim

#Entreprise Linux - Opdracht 8 - Routering

[TOC]

##Bronnen en bitbucket
###Bronnen
* Bron 1) [vyos example](https://github.com/higebu/vagrant-ansible-examples-with-vyos/)
* Bron 2) [Aangepaste vagrantfile](https://github.com/bertvv/ansible-skeleton/blob/master/Vagrantfile)
* Bron 3) [Vagrant](https://docs.vagrantup.com/v2/plugins/development-basics.html)
* Bron 4) [Issue](https://github.com/mapbox/carto/issues/370)
* Bron 5) [vyos guide static](http://vyos.net/wiki/User_Guide#Static)
* Bron 6) [dhcp-relay function](http://www.brocade.com/downloads/documents/html_product_manuals/vyatta/vyatta_5400_manual/Services/wwhelp/wwhimpl/common/html/wwhelp.htm#href=DHCP.2.19.html&single=true)

###Repositories
* Repo 1) [Bitbucket Repo](https://bitbucket.org/stoel/labo/src/)

##Vagrantfile
Vagrant file moeten aanpassen. Hier is uiteindelijk de router en een Client pc bijgekomen (de test pc).
We hebben ook een fout verkregen door een komma te vergeten bij network declaratie. 

##VyOS
Script geschreven voor vyos die te vinden is in onze GitHub repository.
Gebruik gemaakt cheatsheats van Bert

##Intranet server
Opgezet, computers toegevoegd in Vagrant_Hosts en site.yml. Ook de hostvars van de externe webserver gekopieerd voor de functionaliteit van de interne. 

##ClientPC
Toevoegen in de vagrantfile
Via Vagrant_Hosts moet hij een IP adres krijgen maar de DHCP server moet dit doen

Om het ons zelf wat makkelijk te maken hebben we een windows machine genomen om de verbinding te testen in ons netwerk en zo bespaarden we ook wat tijd omdat we in tijdsnood zaten.

##Internal
DHCP Werkt

![Windows Test Dhcp](dhcp.png)

Wordpress Werkt

![Test Wordpress internal](wordpress.png)

##DMZ
Hier werkte alles naar behoren buiten de dns (zie volgende sectie). Bij elke host moeten we wel enkel onder /etc/sysconfig/network het lijntje : ```GATEWAY=192.0.2.254``` toevoegen. Dit zorgt ervoor dat de hosts ook kunnen replyen op een bericht zoals icmp.

###Problemen met DNS
Er waren problemen met het resolven van hostsnames door onze dns, hoewel de toegelaten request range correct was werkte deze toch niet, door het aanpassen naar het volgende werkt alles zoals het moet.
* ALLOW_ANY bij DNS
De server kon zichzelf niet requesten.

Na het oplossen was dit het resultaat:
![Dns resolver works](dns.png)
